<script  context="module">import { getContext, onDestroy, setContext } from 'svelte';
import { writable } from 'svelte/store';
import { useThrelte } from '../hooks/useThrelte';
export const setParent = (objectStore) => {
    setContext('threlte-parent', objectStore);
};
export const getParent = () => {
    return getContext('threlte-parent');
};
</script>

<script >/**
 * GGE 2022: IMPORTANT: get the parent as soon as possible.
 * because svelte contexts are also available inside
 * components that declare the context.
 */
const currentParent = getParent();
let previousParent = $currentParent;
// object property …
export let object;
// … but we only work with this store to stay consistent
const currentObject = writable(object);
$: $currentObject = object;
let previousObject = object;
/**
 * GE 2022: after getting the parent from the context,
 * it's safe to set it to the current object.
 */
setParent(currentObject);
const { invalidate } = useThrelte();
$: {
    // on object change
    if ($currentObject !== previousObject) {
        if (previousObject) {
            $currentParent.remove(previousObject);
        }
        $currentParent.add($currentObject);
        invalidate(`HierarchicalObject: object changed`);
        previousObject = $currentObject;
    }
}
$: {
    // on parent change
    if ($currentParent !== previousParent) {
        previousParent.remove($currentObject);
        $currentParent.add($currentObject);
        invalidate(`HierarchicalObject: parent changed`);
        previousParent = $currentParent;
    }
}
$currentParent.add($currentObject);
invalidate('HierarchicalObject: object added');
onDestroy(() => {
    $currentParent.remove($currentObject);
    invalidate('HierarchicalObject: object removed');
});
</script>

<slot />

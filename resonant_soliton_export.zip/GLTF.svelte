<script >import { createEventDispatcher } from 'svelte';
import { Mesh, Texture } from 'three';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { KTX2Loader } from 'three/examples/jsm/loaders/KTX2Loader';
import { useLoader } from '../hooks/useLoader';
import { useThrelte } from '../hooks/useThrelte';
import Object3DInstance from '../instances/Object3DInstance.svelte';
import InteractiveObject from '../internal/InteractiveObject.svelte';
import LayerableObject from '../internal/LayerableObject.svelte';
import { buildSceneGraph } from '../lib/buildSceneGraph';
export let position = undefined;
export let scale = undefined;
export let rotation = undefined;
export let viewportAware = false;
export let inViewport = false;
export let castShadow = undefined;
export let receiveShadow = undefined;
export let frustumCulled = undefined;
export let renderOrder = undefined;
export let visible = undefined;
export let lookAt = undefined;
export let url;
export let dracoDecoderPath = undefined;
export let ktxTranscoderPath = undefined;
// <InteractiveObject> properties
export let ignorePointer = false;
export let interactive = false;
const { invalidate } = useThrelte();
const dispatch = createEventDispatcher();
let interactiveMeshes = [];
let layerableObjects = [];
export let gltf = undefined;
export let scene = undefined;
export let animations = undefined;
export let asset = undefined;
export let cameras = undefined;
export let scenes = undefined;
export let userData = undefined;
export let parser = undefined;
export let materials = undefined;
export let nodes = undefined;
const loader = useLoader(GLTFLoader, () => new GLTFLoader());
if (dracoDecoderPath) {
    const dracoLoader = useLoader(DRACOLoader, () => new DRACOLoader().setDecoderPath(dracoDecoderPath));
    loader.setDRACOLoader(dracoLoader);
}
const { renderer } = useThrelte();
if (renderer && ktxTranscoderPath) {
    const ktx2Loader = useLoader(KTX2Loader, () => new KTX2Loader().setTranscoderPath(ktxTranscoderPath).detectSupport(renderer));
    loader.setKTX2Loader(ktx2Loader);
}
const disposeGltf = () => {
    if (gltf) {
        gltf.scene.traverse((object) => {
            if (object.type !== 'Mesh')
                return;
            const m = object;
            m.geometry.dispose();
            if (Array.isArray(m.material)) {
                m.material.forEach((mm) => {
                    if (mm.isMaterial) {
                        disposeMaterial(mm);
                    }
                });
            }
            else if (m.material.isMaterial) {
                disposeMaterial(m.material);
            }
        });
        gltf = undefined;
        scene = undefined;
        animations = undefined;
        asset = undefined;
        cameras = undefined;
        scenes = undefined;
        userData = undefined;
        parser = undefined;
        nodes = undefined;
        materials = undefined;
        interactiveMeshes.splice(0, interactiveMeshes.length);
        interactiveMeshes = interactiveMeshes;
        layerableObjects.splice(0, layerableObjects.length);
        layerableObjects = layerableObjects;
        invalidate('GLTF: model disposed');
        dispatch('unload');
    }
};
const disposeMaterial = (material) => {
    material.dispose();
    Object.values(material).forEach((value) => {
        try {
            if (value instanceof Texture) {
                value.dispose();
            }
        }
        catch (error) {
            console.warn('<GLTF>: Unable to dispose texture.');
        }
    });
};
const onLoad = (data) => {
    disposeGltf();
    gltf = data;
    scene = gltf.scene;
    animations = gltf.animations;
    asset = gltf.asset;
    cameras = gltf.cameras;
    scenes = gltf.scenes;
    userData = gltf.userData;
    parser = gltf.parser;
    const { materials: m, nodes: n } = buildSceneGraph(data.scene);
    materials = m;
    nodes = n;
    scene.traverse((object) => {
        layerableObjects.push(object);
        if (object.type === 'Mesh' || object.type === 'SkinnedMesh') {
            const mesh = object;
            interactiveMeshes.push(mesh);
        }
    });
    interactiveMeshes = interactiveMeshes;
    layerableObjects = layerableObjects;
    invalidate('GLTF: model loaded');
    dispatch('load', gltf);
};
const onError = (e) => {
    console.error(`Error loading GLTF: ${e.message}`);
    disposeGltf();
    dispatch('error', e.message);
};
$: loader.load(url, onLoad, undefined, onError);
const objIsMesh = (obj) => {
    return 'isMesh' in obj && obj.isMesh;
};
$: {
    if (scene) {
        scene.traverse((obj) => {
            if (castShadow !== undefined)
                obj.castShadow = castShadow;
            if (receiveShadow !== undefined)
                obj.receiveShadow = receiveShadow;
            if (frustumCulled !== undefined)
                obj.frustumCulled = frustumCulled;
            if (renderOrder !== undefined)
                obj.renderOrder = renderOrder;
        });
    }
}
</script>

{#if scene}
  <Object3DInstance
    object={scene}
    {position}
    {scale}
    {rotation}
    {lookAt}
    {frustumCulled}
    {renderOrder}
    {visible}
    {castShadow}
    {receiveShadow}
    {viewportAware}
    bind:inViewport
    on:viewportenter
    on:viewportleave
  >
    <slot />
  </Object3DInstance>

  {#each interactiveMeshes as mesh}
    {#key mesh.uuid}
      <InteractiveObject
        object={mesh}
        {interactive}
        {ignorePointer}
        on:click
        on:contextmenu
        on:pointerup
        on:pointerdown
        on:pointerenter
        on:pointerleave
        on:pointermove
      />
    {/key}
  {/each}

  {#each layerableObjects as object}
    {#key object.uuid}
      <LayerableObject {object} />
    {/key}
  {/each}
{/if}

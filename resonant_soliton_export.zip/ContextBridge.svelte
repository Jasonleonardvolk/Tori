<script >import { useThrelte } from '../hooks/useThrelte';
import { useThrelteRoot } from '../hooks/useThrelteRoot';
export const ctx = useThrelte();
export const rootCtx = useThrelteRoot();
</script>

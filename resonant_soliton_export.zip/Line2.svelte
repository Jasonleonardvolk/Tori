<script >import { onDestroy } from 'svelte';
import { LineGeometry } from 'three/examples/jsm/lines/LineGeometry';
import { useThrelte } from '../hooks/useThrelte';
import MeshInstance from '../instances/MeshInstance.svelte';
import { Line2 as ThreeLine2 } from 'three/examples/jsm/lines/Line2';
import { Vector3 } from 'three';
// LineInstance
export let position = undefined;
export let scale = undefined;
export let rotation = undefined;
export let viewportAware = false;
export let inViewport = false;
export let castShadow = undefined;
export let receiveShadow = undefined;
export let frustumCulled = undefined;
export let renderOrder = undefined;
export let visible = undefined;
export let interactive = false;
export let ignorePointer = false;
export let lookAt = undefined;
// self
export let points = [];
export let material;
const geometry = new LineGeometry();
const pointTuples = points.map((p) => (p instanceof Vector3 ? p.toArray() : p));
geometry.setPositions(pointTuples.flat());
export const line2 = new ThreeLine2(geometry, material);
line2.computeLineDistances();
onDestroy(() => {
    geometry.dispose();
});
const getLine = () => line2;
const { invalidate } = useThrelte();
let previousMaterial = material;
$: {
    if (material !== previousMaterial) {
        getLine().material = material;
        invalidate('Line2: material changed');
    }
    else {
        invalidate('Line2: material props changed');
    }
    previousMaterial = material;
}
let previousPoints = points;
$: {
    if (points !== previousPoints) {
        const pointTuples = points.map((p) => (p instanceof Vector3 ? p.toArray() : p));
        geometry.setPositions(pointTuples.flat());
        line2.computeLineDistances();
        invalidate('Line2: points changed');
        previousPoints = points;
    }
}
</script>

<MeshInstance
  mesh={line2}
  {position}
  {scale}
  {rotation}
  {lookAt}
  {castShadow}
  {receiveShadow}
  {frustumCulled}
  {renderOrder}
  {visible}
  {interactive}
  {ignorePointer}
  on:click
  on:contextmenu
  on:pointerup
  on:pointerdown
  on:pointerenter
  on:pointerleave
  on:pointermove
  {viewportAware}
  bind:inViewport
  on:viewportenter
  on:viewportleave
>
  <slot />
</MeshInstance>

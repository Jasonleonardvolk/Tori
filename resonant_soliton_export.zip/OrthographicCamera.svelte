<script >import { OrthographicCamera as ThreeOrthographicCamera } from 'three';
import { useThrelte } from '../hooks/useThrelte';
import { useThrelteRoot } from '../hooks/useThrelteRoot';
import CameraInstance from '../instances/CameraInstance.svelte';
// CameraInstance
export let position = undefined;
export let scale = undefined;
export let rotation = undefined;
export let lookAt = undefined;
export let viewportAware = false;
export let inViewport = false;
export let castShadow = undefined;
export let receiveShadow = undefined;
export let frustumCulled = undefined;
export let renderOrder = undefined;
export let visible = undefined;
export let useCamera = true;
// OrthographicCamera
export let near = undefined;
export let far = undefined;
export let zoom = undefined;
const { size, invalidate } = useThrelte();
const { setCamera } = useThrelteRoot();
export const camera = new ThreeOrthographicCamera($size.width / -2, $size.width / 2, $size.height / 2, $size.height / -2, near, far);
$: if (useCamera)
    setCamera(camera);
$: {
    camera.left = $size.width / -2;
    camera.right = $size.width / 2;
    camera.top = $size.height / 2;
    camera.bottom = $size.height / -2;
    camera.updateProjectionMatrix();
    invalidate('OrthographicCamera: onResize');
}
$: {
    if (near !== undefined)
        camera.near = near;
    if (far !== undefined)
        camera.far = far;
    if (zoom !== undefined)
        camera.zoom = zoom;
    camera.updateProjectionMatrix();
    invalidate('OrthographicCamera: props changed');
}
</script>

<CameraInstance
  {camera}
  {position}
  {scale}
  {rotation}
  {castShadow}
  {receiveShadow}
  {frustumCulled}
  {renderOrder}
  {visible}
  {viewportAware}
  bind:inViewport
  on:viewportenter
  on:viewportleave
  {lookAt}
  {useCamera}
>
  <slot />
</CameraInstance>

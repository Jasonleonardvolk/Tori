#!/bin/bash
# INSTALL CONCURRENTLY - Run this once
echo "📦 Installing concurrently for integrated development..."
cd "C:\Users\jason\Desktop\tori\kha\tori_ui_svelte"
npm install concurrently --save-dev
echo "✅ Setup complete!"
"""
Tests for the Koopman module.
"""

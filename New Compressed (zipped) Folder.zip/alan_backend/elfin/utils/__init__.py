"""
Utility modules for ELFIN.

This package contains various utility modules that are used by ELFIN components.
"""

"""
Prajna Language Model: The Voice and Mouth of TORI
==================================================

This module implements Prajna - TORI's custom-trained language model.
Prajna is trained from scratch using ONLY data ingested through TORI's pipeline.
No external corpora, no pre-trained weights, complete privacy and provenance.

Prajna is the singular voice of the TORI cognitive system - all language output
comes from Prajna's neural architecture trained exclusively on your data.
"""

import asyncio
import logging
import time
import torch
import numpy as np
from typing import Optional, Dict, Any, AsyncGenerator, List
from dataclasses import dataclass
from pathlib import Path

# Import model architectures (can be swapped)
try:
    from transformers import AutoTokenizer, AutoModelForCausalLM
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False

try:
    import rwkv
    RWKV_AVAILABLE = True
except ImportError:
    RWKV_AVAILABLE = False

from ..memory.context_builder import ContextResult

logger = logging.getLogger("prajna.core")

@dataclass
class PrajnaOutput:
    """Container for Prajna's generated response"""
    answer: str
    tokens_generated: int
    generation_time: float
    confidence_score: float
    internal_states: Dict[str, Any] = None

class PrajnaLanguageModel:
    """
    Prajna Language Model - TORI's Voice and Mouth
    
    This is the core neural network that generates all language output in TORI.
    Prajna is trained from scratch using only your ingested data - complete privacy.
    """
    
    def __init__(
        self,
        model_type: str = "rwkv",
        model_path: str = "./models/prajna_v1.pth",
        device: str = "auto",
        max_context_length: int = 2048,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 50
    ):
        self.model_type = model_type.lower()
        self.model_path = Path(model_path)
        self.device = self._setup_device(device)
        self.max_context_length = max_context_length
        self.temperature = temperature
        self.top_p = top_p
        self.top_k = top_k
        
        # Model components
        self.model = None
        self.tokenizer = None
        self.is_model_loaded = False
        
        # Performance tracking
        self.generation_count = 0
        self.total_tokens_generated = 0
        self.total_generation_time = 0.0
        
        logger.info(f"🧠 Prajna initialized: {model_type} on {self.device}")
    
    def _setup_device(self, device: str) -> str:
        """Setup optimal device for Prajna inference"""
        if device == "auto":
            if torch.cuda.is_available():
                return "cuda"
            elif torch.backends.mps.is_available():
                return "mps"
            else:
                return "cpu"
        return device
    
    async def load_model(self):
        """Load Prajna model and tokenizer"""
        try:
            logger.info(f"🔄 Loading Prajna model: {self.model_path}")
            
            if self.model_type == "rwkv" and RWKV_AVAILABLE:
                await self._load_rwkv_model()
            elif self.model_type in ["llama", "gpt"] and HF_AVAILABLE:
                await self._load_huggingface_model()
            elif self.model_type == "custom":
                await self._load_custom_model()
            else:
                # Fallback to tiny demo model for development
                await self._load_demo_model()
            
            self.is_model_loaded = True
            logger.info("✅ Prajna model loaded successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to load Prajna model: {e}")
            raise
    
    async def _load_rwkv_model(self):
        """Load RWKV-based Prajna model"""
        if not self.model_path.exists():
            logger.warning(f"Prajna model not found at {self.model_path}, creating demo model")
            await self._create_demo_rwkv_model()
        
        # Load RWKV model
        self.model = rwkv.RWKV(
            model=str(self.model_path),
            strategy=f'{self.device} bf16' if self.device == 'cuda' else self.device
        )
        
        # RWKV tokenizer
        self.tokenizer = rwkv.utils.TOKENIZER("rwkv_vocab_v20230424.txt")
        logger.info("🔄 RWKV Prajna model loaded")
    
    async def _load_huggingface_model(self):
        """Load HuggingFace-based Prajna model"""
        if not self.model_path.exists():
            logger.warning(f"Prajna model not found, using TinyLlama for development")
            model_name = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
        else:
            model_name = str(self.model_path)
        
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
            device_map=self.device if self.device == "cuda" else None
        )
        
        if self.device != "cuda":
            self.model = self.model.to(self.device)
        
        logger.info(f"🔄 HuggingFace Prajna model loaded: {model_name}")
    
    async def _load_custom_model(self):
        """Load custom Prajna architecture"""
        # Implement your custom Prajna architecture here
        logger.info("🔄 Custom Prajna architecture not implemented yet")
        await self._load_demo_model()
    
    async def _load_demo_model(self):
        """Load demo model for development/testing"""
        logger.warning("🚧 Loading demo Prajna model for development")
        
        # Create a simple demo model that echoes context
        class DemoPrajnaModel:
            def generate(self, prompt: str, **kwargs) -> str:
                # Simple echo with context awareness
                if "context:" in prompt.lower():
                    context_start = prompt.lower().find("context:")
                    context_end = prompt.lower().find("question:", context_start)
                    if context_end > context_start:
                        context = prompt[context_start:context_end].strip()
                        return f"Based on the provided context, I can tell you that this information comes from TORI's ingested knowledge. [Demo Prajna Response]"
                return "I am Prajna, TORI's voice. This is a demo response. [Demo Mode]"
        
        self.model = DemoPrajnaModel()
        self.tokenizer = None  # Demo doesn't need tokenizer
        
    async def _create_demo_rwkv_model(self):
        """Create a minimal RWKV model for development"""
        # This would create a small RWKV model file
        # For now, just log that we need the actual model
        logger.warning("🚧 Demo RWKV model creation not implemented")
    
    async def generate_answer(
        self,
        query: str,
        context: ContextResult,
        max_tokens: int = 512
    ) -> PrajnaOutput:
        """
        Generate Prajna's answer to a query using provided context
        
        This is Prajna's core function - where the voice speaks.
        """
        if not self.is_model_loaded:
            raise RuntimeError("Prajna model not loaded")
        
        start_time = time.time()
        
        try:
            # Build Prajna's prompt
            prompt = self._build_prajna_prompt(query, context)
            
            # Generate response based on model type
            if self.model_type == "rwkv":
                answer = await self._generate_rwkv(prompt, max_tokens)
            elif self.model_type in ["llama", "gpt"]:
                answer = await self._generate_huggingface(prompt, max_tokens)
            else:
                answer = await self._generate_demo(prompt, max_tokens)
            
            generation_time = time.time() - start_time
            
            # Update statistics
            self.generation_count += 1
            self.total_generation_time += generation_time
            
            # Calculate confidence (simplified for now)
            confidence = min(1.0, len(answer) / 100.0)  # Simple heuristic
            
            logger.info(f"🗣️ Prajna generated {len(answer)} chars in {generation_time:.2f}s")
            
            return PrajnaOutput(
                answer=answer,
                tokens_generated=len(answer.split()),  # Approximate
                generation_time=generation_time,
                confidence_score=confidence
            )
            
        except Exception as e:
            logger.error(f"❌ Prajna generation failed: {e}")
            raise
    
    def _build_prajna_prompt(self, query: str, context: ContextResult) -> str:
        """
        Build the prompt for Prajna using TORI's context
        
        This ensures Prajna only speaks from known, ingested knowledge.
        """
        prompt_template = """You are Prajna, the voice of the TORI cognitive system. You generate answers using ONLY the provided context from TORI's memory and knowledge mesh. Never use external knowledge.

CONTEXT FROM TORI'S MEMORY:
{context}

SOURCES: {sources}

USER QUESTION: {query}

PRAJNA'S ANSWER (using only the above context):"""
        
        return prompt_template.format(
            context=context.text,
            sources=", ".join(context.sources) if context.sources else "TORI Memory",
            query=query
        )
    
    async def _generate_rwkv(self, prompt: str, max_tokens: int) -> str:
        """Generate using RWKV model"""
        try:
            # Encode prompt
            tokens = self.tokenizer.encode(prompt)
            
            # Generate with RWKV
            output_tokens = []
            state = None
            
            for i in range(max_tokens):
                if i == 0:
                    # Initial pass with full prompt
                    logits, state = self.model.forward(tokens, state)
                else:
                    # Continue generation
                    logits, state = self.model.forward([token], state)
                
                # Sample next token
                token = self._sample_token(logits)
                output_tokens.append(token)
                
                # Check for end token
                if token == 0:  # Assuming 0 is EOS
                    break
            
            # Decode answer
            answer = self.tokenizer.decode(output_tokens)
            return answer.strip()
            
        except Exception as e:
            logger.error(f"RWKV generation error: {e}")
            return f"Prajna (RWKV) encountered an error: {e}"
    
    async def _generate_huggingface(self, prompt: str, max_tokens: int) -> str:
        """Generate using HuggingFace model"""
        try:
            # Tokenize input
            inputs = self.tokenizer.encode(prompt, return_tensors="pt").to(self.device)
            
            # Generate
            with torch.no_grad():
                outputs = self.model.generate(
                    inputs,
                    max_new_tokens=max_tokens,
                    temperature=self.temperature,
                    top_p=self.top_p,
                    top_k=self.top_k,
                    do_sample=True,
                    pad_token_id=self.tokenizer.eos_token_id
                )
            
            # Decode only the new tokens
            answer = self.tokenizer.decode(
                outputs[0][inputs.shape[-1]:], 
                skip_special_tokens=True
            )
            
            return answer.strip()
            
        except Exception as e:
            logger.error(f"HuggingFace generation error: {e}")
            return f"Prajna (HF) encountered an error: {e}"
    
    async def _generate_demo(self, prompt: str, max_tokens: int) -> str:
        """Generate using demo model"""
        return self.model.generate(prompt, max_tokens=max_tokens)
    
    def _sample_token(self, logits: torch.Tensor) -> int:
        """Sample next token using temperature and top-p"""
        logits = logits / self.temperature
        
        # Apply top-k filtering
        if self.top_k > 0:
            top_k_logits, top_k_indices = torch.topk(logits, self.top_k)
            logits = torch.full_like(logits, float('-inf'))
            logits.scatter_(0, top_k_indices, top_k_logits)
        
        # Apply top-p filtering
        if self.top_p < 1.0:
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
            sorted_indices_to_remove = cumulative_probs > self.top_p
            sorted_indices_to_remove[1:] = sorted_indices_to_remove[:-1].clone()
            sorted_indices_to_remove[0] = False
            indices_to_remove = sorted_indices[sorted_indices_to_remove]
            logits[indices_to_remove] = float('-inf')
        
        # Sample
        probs = torch.softmax(logits, dim=-1)
        token = torch.multinomial(probs, 1).item()
        return token
    
    async def stream_generate(
        self,
        query: str,
        context: ContextResult
    ) -> AsyncGenerator[str, None]:
        """Stream Prajna's response generation token by token"""
        if not self.is_model_loaded:
            raise RuntimeError("Prajna model not loaded")
        
        prompt = self._build_prajna_prompt(query, context)
        
        # For now, simulate streaming by yielding chunks
        # TODO: Implement true token-by-token streaming
        full_response = await self.generate_answer(query, context)
        
        words = full_response.answer.split()
        for i, word in enumerate(words):
            yield word + " "
            await asyncio.sleep(0.05)  # Simulate streaming delay
    
    def is_loaded(self) -> bool:
        """Check if Prajna model is loaded"""
        return self.is_model_loaded
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get Prajna model statistics"""
        return {
            "model_type": self.model_type,
            "model_path": str(self.model_path),
            "device": self.device,
            "is_loaded": self.is_model_loaded,
            "generation_count": self.generation_count,
            "total_tokens_generated": self.total_tokens_generated,
            "total_generation_time": self.total_generation_time,
            "average_generation_time": (
                self.total_generation_time / self.generation_count 
                if self.generation_count > 0 else 0
            )
        }
    
    async def cleanup(self):
        """Cleanup Prajna model resources"""
        if self.model:
            if hasattr(self.model, 'to'):
                self.model.to('cpu')  # Move to CPU to free GPU memory
            del self.model
            self.model = None
        
        if self.tokenizer:
            del self.tokenizer
            self.tokenizer = None
        
        self.is_model_loaded = False
        logger.info("🧹 Prajna model cleaned up")

# Global function for easy access
async def generate_prajna_response(
    query: str,
    context: ContextResult,
    model: PrajnaLanguageModel,
    streaming: bool = False
) -> PrajnaOutput:
    """
    Generate a response from Prajna (TORI's voice)
    
    This is the main entry point for getting Prajna to speak.
    """
    logger.info(f"🗣️ Prajna speaking: {query[:50]}...")
    
    if streaming:
        # Return streaming response (implement as needed)
        pass
    
    return await model.generate_answer(query, context)

if __name__ == "__main__":
    # Demo/test Prajna
    async def demo_prajna():
        prajna = PrajnaLanguageModel(model_type="demo")
        await prajna.load_model()
        
        # Mock context
        from ..memory.context_builder import ContextResult
        context = ContextResult(
            text="This is demo context from TORI's memory.",
            sources=["demo_source.txt"]
        )
        
        output = await prajna.generate_answer("What is TORI?", context)
        print(f"Prajna says: {output.answer}")
        
        await prajna.cleanup()
    
    asyncio.run(demo_prajna())

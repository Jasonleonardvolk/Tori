"""
Soliton Memory Interface: Phase-Based Memory Integration for Prajna
==================================================================

This module provides the interface to TORI's Soliton Memory system.
Soliton Memory stores personal/conversational memory using phase dynamics,
allowing for coherent recall of past interactions and learned context.

Both REST API and FFI interfaces are supported for different use cases:
- REST API: Language-agnostic, easier scaling, async operations
- FFI: High-performance batch operations, system-level integration
"""

import asyncio
import aiohttp
import json
import logging
import time
from typing import List, Dict, Any, Optional
from datetime import datetime
from dataclasses import dataclass

try:
    import ctypes
    import ctypes.util
    FFI_AVAILABLE = True
except ImportError:
    FFI_AVAILABLE = False

logger = logging.getLogger("prajna.soliton")

@dataclass
class SolitonQueryResult:
    """Result from Soliton Memory query"""
    text: str
    source: str
    relevance: float
    timestamp: Optional[datetime] = None
    phase_signature: Optional[Dict[str, float]] = None
    memory_id: Optional[str] = None

class SolitonMemoryInterface:
    """
    Interface to TORI's Soliton Memory system
    
    Provides both REST and FFI access to phase-based personal memory.
    """
    
    def __init__(
        self,
        rest_endpoint: str = "http://localhost:8002",
        ffi_enabled: bool = False,
        ffi_lib_path: Optional[str] = None,
        timeout: float = 10.0
    ):
        self.rest_endpoint = rest_endpoint.rstrip('/')
        self.ffi_enabled = ffi_enabled and FFI_AVAILABLE
        self.ffi_lib_path = ffi_lib_path
        self.timeout = timeout
        
        # Connection objects
        self.session: Optional[aiohttp.ClientSession] = None
        self.ffi_lib: Optional[ctypes.CDLL] = None
        
        # Performance tracking
        self.query_count = 0
        self.total_query_time = 0.0
        
        logger.info(f"🌊 Soliton Memory interface initialized (REST: {rest_endpoint}, FFI: {ffi_enabled})")
    
    async def initialize(self):
        """Initialize connections to Soliton Memory"""
        try:
            # Initialize REST session
            self.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )
            
            # Test REST connection
            await self._test_rest_connection()
            
            # Initialize FFI if enabled
            if self.ffi_enabled:
                await self._initialize_ffi()
            
            logger.info("✅ Soliton Memory interface ready")
            
        except Exception as e:
            logger.error(f"❌ Soliton Memory initialization failed: {e}")
            raise
    
    async def _test_rest_connection(self):
        """Test REST API connection"""
        try:
            async with self.session.get(f"{self.rest_endpoint}/health") as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"🌊 Soliton Memory REST API healthy: {data.get('status', 'unknown')}")
                else:
                    logger.warning(f"⚠️ Soliton Memory REST API returned {response.status}")
        except Exception as e:
            logger.warning(f"⚠️ Soliton Memory REST API not available: {e}")
    
    async def _initialize_ffi(self):
        """Initialize FFI connection to Rust Soliton Memory"""
        try:
            if not self.ffi_lib_path:
                # Try to find the library automatically
                lib_name = "soliton_memory"  # Adjust based on your Rust lib name
                self.ffi_lib_path = ctypes.util.find_library(lib_name)
            
            if self.ffi_lib_path:
                self.ffi_lib = ctypes.CDLL(self.ffi_lib_path)
                # Setup function signatures (adjust based on your Rust API)
                self._setup_ffi_signatures()
                logger.info(f"🦀 Soliton Memory FFI loaded: {self.ffi_lib_path}")
            else:
                logger.warning("⚠️ Soliton Memory FFI library not found")
                self.ffi_enabled = False
                
        except Exception as e:
            logger.error(f"❌ Soliton Memory FFI initialization failed: {e}")
            self.ffi_enabled = False
    
    def _setup_ffi_signatures(self):
        """Setup FFI function signatures for Rust library"""
        try:
            # Example FFI function signatures (adjust based on your Rust API)
            self.ffi_lib.soliton_query.argtypes = [
                ctypes.c_char_p,  # query
                ctypes.c_char_p,  # concepts_json
                ctypes.c_char_p,  # conversation_id
                ctypes.c_int      # max_results
            ]
            self.ffi_lib.soliton_query.restype = ctypes.c_char_p
            
            self.ffi_lib.soliton_store.argtypes = [
                ctypes.c_char_p,  # text
                ctypes.c_char_p,  # source
                ctypes.c_char_p   # metadata_json
            ]
            self.ffi_lib.soliton_store.restype = ctypes.c_bool
            
        except Exception as e:
            logger.error(f"❌ FFI signature setup failed: {e}")
            self.ffi_enabled = False
    
    async def query_memory(
        self,
        query: str,
        concepts: List[str],
        conversation_id: Optional[str] = None,
        max_results: int = 10
    ) -> List[SolitonQueryResult]:
        """
        Query Soliton Memory for relevant memories
        
        Uses REST API by default, falls back to FFI for high-performance operations.
        """
        start_time = time.time()
        
        try:
            logger.info(f"🌊 Querying Soliton Memory: {query[:50]}...")
            
            # Try REST API first
            results = await self._query_rest(query, concepts, conversation_id, max_results)
            
            # Fall back to FFI if REST fails and FFI is available
            if not results and self.ffi_enabled:
                logger.info("🦀 Falling back to Soliton Memory FFI")
                results = await self._query_ffi(query, concepts, conversation_id, max_results)
            
            # If no results, create a synthetic "no memory" result
            if not results:
                results = [SolitonQueryResult(
                    text="No relevant memories found in Soliton Memory.",
                    source="soliton_empty",
                    relevance=0.1
                )]
            
            query_time = time.time() - start_time
            self.query_count += 1
            self.total_query_time += query_time
            
            logger.info(f"🌊 Soliton Memory returned {len(results)} results in {query_time:.2f}s")
            return results
            
        except Exception as e:
            logger.error(f"❌ Soliton Memory query failed: {e}")
            return []
    
    async def _query_rest(
        self,
        query: str,
        concepts: List[str],
        conversation_id: Optional[str],
        max_results: int
    ) -> List[SolitonQueryResult]:
        """Query via REST API"""
        try:
            request_payload = {
                "query": query,
                "concepts": concepts,
                "conversation_id": conversation_id,
                "max_results": max_results,
                "include_phase_signature": True
            }
            
            async with self.session.post(
                f"{self.rest_endpoint}/query",
                json=request_payload
            ) as response:
                
                if response.status == 200:
                    data = await response.json()
                    return self._parse_rest_results(data.get("results", []))
                else:
                    error_text = await response.text()
                    logger.error(f"Soliton Memory REST error {response.status}: {error_text}")
                    return []
                    
        except Exception as e:
            logger.error(f"❌ Soliton Memory REST query failed: {e}")
            return []
    
    async def _query_ffi(
        self,
        query: str,
        concepts: List[str],
        conversation_id: Optional[str],
        max_results: int
    ) -> List[SolitonQueryResult]:
        """Query via FFI (high-performance)"""
        try:
            # Prepare FFI parameters
            query_bytes = query.encode('utf-8')
            concepts_json = json.dumps(concepts).encode('utf-8')
            conv_id_bytes = (conversation_id or "").encode('utf-8')
            
            # Call FFI function
            result_ptr = self.ffi_lib.soliton_query(
                query_bytes,
                concepts_json,
                conv_id_bytes,
                max_results
            )
            
            if result_ptr:
                # Parse JSON result from FFI
                result_json = ctypes.string_at(result_ptr).decode('utf-8')
                result_data = json.loads(result_json)
                return self._parse_ffi_results(result_data)
            else:
                return []
                
        except Exception as e:
            logger.error(f"❌ Soliton Memory FFI query failed: {e}")
            return []
    
    def _parse_rest_results(self, results: List[Dict[str, Any]]) -> List[SolitonQueryResult]:
        """Parse REST API results into SolitonQueryResult objects"""
        parsed_results = []
        
        for result in results:
            timestamp = None
            if result.get("timestamp"):
                try:
                    timestamp = datetime.fromisoformat(result["timestamp"])
                except:
                    pass
            
            parsed_results.append(SolitonQueryResult(
                text=result.get("text", ""),
                source=result.get("source", "soliton_memory"),
                relevance=result.get("relevance", 0.5),
                timestamp=timestamp,
                phase_signature=result.get("phase_signature"),
                memory_id=result.get("memory_id")
            ))
        
        return parsed_results
    
    def _parse_ffi_results(self, results: List[Dict[str, Any]]) -> List[SolitonQueryResult]:
        """Parse FFI results into SolitonQueryResult objects"""
        # Similar to REST parsing, but may have different field names
        return self._parse_rest_results(results)
    
    async def store_memory(
        self,
        text: str,
        source: str,
        conversation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Store new memory in Soliton Memory system"""
        try:
            logger.info(f"🌊 Storing memory: {text[:50]}...")
            
            # Try REST API first
            success = await self._store_rest(text, source, conversation_id, metadata)
            
            # Fall back to FFI if REST fails and FFI is available
            if not success and self.ffi_enabled:
                success = await self._store_ffi(text, source, conversation_id, metadata)
            
            if success:
                logger.info("✅ Memory stored in Soliton Memory")
            else:
                logger.warning("⚠️ Failed to store memory in Soliton Memory")
            
            return success
            
        except Exception as e:
            logger.error(f"❌ Soliton Memory storage failed: {e}")
            return False
    
    async def _store_rest(
        self,
        text: str,
        source: str,
        conversation_id: Optional[str],
        metadata: Optional[Dict[str, Any]]
    ) -> bool:
        """Store memory via REST API"""
        try:
            request_payload = {
                "text": text,
                "source": source,
                "conversation_id": conversation_id,
                "metadata": metadata or {},
                "timestamp": datetime.now().isoformat()
            }
            
            async with self.session.post(
                f"{self.rest_endpoint}/store",
                json=request_payload
            ) as response:
                return response.status == 200
                
        except Exception as e:
            logger.error(f"❌ Soliton Memory REST storage failed: {e}")
            return False
    
    async def _store_ffi(
        self,
        text: str,
        source: str,
        conversation_id: Optional[str],
        metadata: Optional[Dict[str, Any]]
    ) -> bool:
        """Store memory via FFI"""
        try:
            text_bytes = text.encode('utf-8')
            source_bytes = source.encode('utf-8')
            
            metadata_dict = metadata or {}
            if conversation_id:
                metadata_dict["conversation_id"] = conversation_id
            metadata_json = json.dumps(metadata_dict).encode('utf-8')
            
            result = self.ffi_lib.soliton_store(text_bytes, source_bytes, metadata_json)
            return bool(result)
            
        except Exception as e:
            logger.error(f"❌ Soliton Memory FFI storage failed: {e}")
            return False
    
    async def health_check(self) -> bool:
        """Check health of Soliton Memory system"""
        try:
            if self.session:
                async with self.session.get(f"{self.rest_endpoint}/health") as response:
                    return response.status == 200
            return False
        except:
            return False
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get Soliton Memory system statistics"""
        stats = {
            "interface_type": "REST + FFI" if self.ffi_enabled else "REST",
            "endpoint": self.rest_endpoint,
            "ffi_enabled": self.ffi_enabled,
            "query_count": self.query_count,
            "total_query_time": self.total_query_time,
            "average_query_time": (
                self.total_query_time / self.query_count 
                if self.query_count > 0 else 0
            )
        }
        
        # Try to get system stats from REST API
        try:
            if self.session:
                async with self.session.get(f"{self.rest_endpoint}/stats") as response:
                    if response.status == 200:
                        system_stats = await response.json()
                        stats.update(system_stats)
        except:
            pass
        
        return stats
    
    async def cleanup(self):
        """Cleanup Soliton Memory interface"""
        if self.session:
            await self.session.close()
            self.session = None
        
        if self.ffi_lib:
            # FFI libraries are automatically cleaned up
            self.ffi_lib = None
        
        logger.info("🧹 Soliton Memory interface cleaned up")

if __name__ == "__main__":
    # Demo Soliton Memory interface
    async def demo_soliton():
        soliton = SolitonMemoryInterface()
        await soliton.initialize()
        
        # Test query
        results = await soliton.query_memory(
            query="What did we discuss about quantum dynamics?",
            concepts=["quantum", "dynamics"],
            conversation_id="demo_session"
        )
        
        for result in results:
            print(f"Memory: {result.text[:100]}...")
            print(f"Source: {result.source}, Relevance: {result.relevance}")
        
        # Test storage
        success = await soliton.store_memory(
            text="This is a demo memory about quantum phase dynamics.",
            source="demo_conversation",
            conversation_id="demo_session"
        )
        
        print(f"Storage success: {success}")
        
        await soliton.cleanup()
    
    asyncio.run(demo_soliton())

"""
Concept Mesh API: Knowledge Graph Integration for Prajna
========================================================

This module provides the interface to TORI's Concept Mesh system.
The Concept Mesh is an in-memory knowledge graph built from ingested content:
- PDFs, documents, textbooks
- Video transcripts
- Image OCR and captions
- Structured knowledge nodes

The mesh stores all factual knowledge that Prajna can reference,
ensuring complete traceability and privacy (no external data).
"""

import asyncio
import json
import logging
import time
import pickle
import numpy as np
from typing import List, Dict, Any, Optional, Set, Tuple
from datetime import datetime
from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict

try:
    import networkx as nx
    NETWORKX_AVAILABLE = True
except ImportError:
    NETWORKX_AVAILABLE = False

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

logger = logging.getLogger("prajna.concept_mesh")

@dataclass
class ConceptNode:
    """A node in the Concept Mesh knowledge graph"""
    concept_id: str
    name: str
    text: str
    source: str
    node_type: str  # "document", "concept", "entity", "relation"
    created_at: datetime
    metadata: Dict[str, Any]
    embedding: Optional[np.ndarray] = None
    connections: Set[str] = None

    def __post_init__(self):
        if self.connections is None:
            self.connections = set()

@dataclass
class ConceptQueryResult:
    """Result from Concept Mesh query"""
    text: str
    source: str
    relevance: float
    concept_id: str
    node_type: str
    connections: List[str] = None

class ConceptMeshAPI:
    """
    Interface to TORI's Concept Mesh knowledge graph
    
    Manages in-memory knowledge graph with optional snapshotting to disk.
    Provides semantic search and concept relationship traversal.
    """
    
    def __init__(
        self,
        in_memory_graph: bool = True,
        snapshot_path: str = "./concept_mesh_snapshot.pkl",
        max_nodes: int = 100000,
        embedding_dim: int = 384
    ):
        self.in_memory_graph = in_memory_graph
        self.snapshot_path = Path(snapshot_path)
        self.max_nodes = max_nodes
        self.embedding_dim = embedding_dim
        
        # Core data structures
        self.nodes: Dict[str, ConceptNode] = {}
        self.graph: Optional[nx.Graph] = None
        self.embeddings: Optional[np.ndarray] = None
        self.embedding_index: Dict[str, int] = {}
        
        # Search infrastructure
        self.tfidf_vectorizer: Optional[TfidfVectorizer] = None
        self.tfidf_matrix: Optional[np.ndarray] = None
        
        # Performance tracking
        self.query_count = 0
        self.total_query_time = 0.0
        self.last_snapshot_time = None
        
        logger.info(f"🕸️ Concept Mesh API initialized (in_memory: {in_memory_graph})")
    
    async def initialize(self):
        """Initialize Concept Mesh system"""
        try:
            logger.info("🔄 Initializing Concept Mesh...")
            
            # Initialize graph structure
            if NETWORKX_AVAILABLE:
                self.graph = nx.Graph()
            
            # Load existing snapshot if available
            if self.snapshot_path.exists():
                await self._load_snapshot()
            else:
                logger.info("📝 Creating new Concept Mesh")
                await self._create_demo_mesh()
            
            # Initialize search infrastructure
            await self._build_search_index()
            
            logger.info(f"✅ Concept Mesh ready with {len(self.nodes)} nodes")
            
        except Exception as e:
            logger.error(f"❌ Concept Mesh initialization failed: {e}")
            raise
    
    async def _load_snapshot(self):
        """Load Concept Mesh from snapshot file"""
        try:
            logger.info(f"📂 Loading Concept Mesh snapshot: {self.snapshot_path}")
            
            with open(self.snapshot_path, 'rb') as f:
                snapshot_data = pickle.load(f)
            
            self.nodes = snapshot_data.get("nodes", {})
            self.embedding_index = snapshot_data.get("embedding_index", {})
            self.embeddings = snapshot_data.get("embeddings")
            self.last_snapshot_time = snapshot_data.get("timestamp")
            
            # Rebuild graph from nodes
            if NETWORKX_AVAILABLE and self.graph is not None:
                for node in self.nodes.values():
                    self.graph.add_node(node.concept_id, **node.metadata)
                    for connection in node.connections:
                        if connection in self.nodes:
                            self.graph.add_edge(node.concept_id, connection)
            
            logger.info(f"📂 Loaded {len(self.nodes)} nodes from snapshot")
            
        except Exception as e:
            logger.error(f"❌ Failed to load snapshot: {e}")
            await self._create_demo_mesh()
    
    async def _create_demo_mesh(self):
        """Create a demo Concept Mesh for development"""
        logger.info("🚧 Creating demo Concept Mesh")
        
        # Demo nodes representing TORI concepts
        demo_concepts = [
            {
                "name": "Quantum Phase Dynamics",
                "text": "Quantum phase dynamics involves the evolution of quantum systems through phase space, incorporating both classical and quantum mechanical principles.",
                "source": "physics_textbook.pdf",
                "node_type": "concept"
            },
            {
                "name": "Soliton Memory",
                "text": "Soliton Memory is a phase-based memory system that uses wave-like structures to store and retrieve information coherently.",
                "source": "tori_documentation.md",
                "node_type": "concept"
            },
            {
                "name": "Prajna Language Model",
                "text": "Prajna is TORI's voice and language model, trained exclusively on ingested data to ensure complete privacy and traceability.",
                "source": "tori_architecture.md",
                "node_type": "concept"
            },
            {
                "name": "Concept Mesh",
                "text": "The Concept Mesh is TORI's knowledge graph that stores relationships between concepts, documents, and entities.",
                "source": "tori_architecture.md",
                "node_type": "concept"
            }
        ]
        
        for i, concept_data in enumerate(demo_concepts):
            concept_id = f"demo_concept_{i}"
            node = ConceptNode(
                concept_id=concept_id,
                name=concept_data["name"],
                text=concept_data["text"],
                source=concept_data["source"],
                node_type=concept_data["node_type"],
                created_at=datetime.now(),
                metadata={"demo": True}
            )
            self.nodes[concept_id] = node
            
            if self.graph:
                self.graph.add_node(concept_id, **node.metadata)
        
        # Add some demo connections
        if len(self.nodes) >= 4:
            node_ids = list(self.nodes.keys())
            self.nodes[node_ids[0]].connections.add(node_ids[1])  # Quantum -> Soliton
            self.nodes[node_ids[1]].connections.add(node_ids[0])
            self.nodes[node_ids[2]].connections.add(node_ids[3])  # Prajna -> Concept Mesh
            self.nodes[node_ids[3]].connections.add(node_ids[2])
            
            if self.graph:
                self.graph.add_edge(node_ids[0], node_ids[1])
                self.graph.add_edge(node_ids[2], node_ids[3])
    
    async def _build_search_index(self):
        """Build search indexes for efficient querying"""
        try:
            if not self.nodes:
                return
            
            logger.info("🔍 Building Concept Mesh search index...")
            
            # Build TF-IDF index if sklearn is available
            if SKLEARN_AVAILABLE:
                texts = [node.text for node in self.nodes.values()]
                self.tfidf_vectorizer = TfidfVectorizer(
                    max_features=10000,
                    stop_words='english',
                    ngram_range=(1, 2)
                )
                self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(texts)
            
            # Create simple embeddings (in real system, use actual embeddings)
            if SKLEARN_AVAILABLE:
                self.embeddings = self.tfidf_matrix.toarray().astype(np.float32)
                self.embedding_index = {
                    concept_id: i for i, concept_id in enumerate(self.nodes.keys())
                }
            
            logger.info("✅ Search index built")
            
        except Exception as e:
            logger.error(f"❌ Search index building failed: {e}")
    
    async def query_concepts(
        self,
        query: str,
        concepts: List[str],
        max_results: int = 10
    ) -> List[ConceptQueryResult]:
        """
        Query Concept Mesh for relevant knowledge nodes
        """
        start_time = time.time()
        
        try:
            logger.info(f"🕸️ Querying Concept Mesh: {query[:50]}...")
            
            results = []
            
            # Method 1: Direct concept name matching
            name_matches = await self._query_by_concept_names(concepts, max_results // 2)
            results.extend(name_matches)
            
            # Method 2: Text similarity search
            text_matches = await self._query_by_text_similarity(query, max_results // 2)
            results.extend(text_matches)
            
            # Method 3: Graph traversal for related concepts
            if len(results) > 0:
                related_matches = await self._query_by_graph_traversal(
                    [r.concept_id for r in results[:3]], 
                    max_results // 3
                )
                results.extend(related_matches)
            
            # Remove duplicates and rank
            unique_results = self._deduplicate_and_rank_results(results, query)
            
            # Limit to max_results
            final_results = unique_results[:max_results]
            
            query_time = time.time() - start_time
            self.query_count += 1
            self.total_query_time += query_time
            
            logger.info(f"🕸️ Concept Mesh returned {len(final_results)} results in {query_time:.2f}s")
            return final_results
            
        except Exception as e:
            logger.error(f"❌ Concept Mesh query failed: {e}")
            return []
    
    async def _query_by_concept_names(self, concepts: List[str], max_results: int) -> List[ConceptQueryResult]:
        """Query by matching concept names"""
        results = []
        
        for concept in concepts:
            concept_lower = concept.lower()
            for node in self.nodes.values():
                if concept_lower in node.name.lower() or concept_lower in node.text.lower():
                    # Calculate relevance based on name match
                    name_match_score = 1.0 if concept_lower in node.name.lower() else 0.5
                    
                    results.append(ConceptQueryResult(
                        text=node.text,
                        source=node.source,
                        relevance=name_match_score,
                        concept_id=node.concept_id,
                        node_type=node.node_type,
                        connections=list(node.connections)
                    ))
        
        return results[:max_results]
    
    async def _query_by_text_similarity(self, query: str, max_results: int) -> List[ConceptQueryResult]:
        """Query by text similarity using TF-IDF"""
        results = []
        
        if not SKLEARN_AVAILABLE or self.tfidf_vectorizer is None:
            # Fallback to simple text matching
            query_lower = query.lower()
            for node in self.nodes.values():
                if any(word in node.text.lower() for word in query_lower.split()):
                    results.append(ConceptQueryResult(
                        text=node.text,
                        source=node.source,
                        relevance=0.6,
                        concept_id=node.concept_id,
                        node_type=node.node_type,
                        connections=list(node.connections)
                    ))
            return results[:max_results]
        
        try:
            # Transform query to TF-IDF vector
            query_vector = self.tfidf_vectorizer.transform([query])
            
            # Calculate similarities
            similarities = cosine_similarity(query_vector, self.tfidf_matrix).flatten()
            
            # Get top matches
            top_indices = np.argsort(similarities)[::-1][:max_results]
            
            for idx in top_indices:
                if similarities[idx] > 0.1:  # Relevance threshold
                    concept_id = list(self.nodes.keys())[idx]
                    node = self.nodes[concept_id]
                    
                    results.append(ConceptQueryResult(
                        text=node.text,
                        source=node.source,
                        relevance=float(similarities[idx]),
                        concept_id=node.concept_id,
                        node_type=node.node_type,
                        connections=list(node.connections)
                    ))
            
        except Exception as e:
            logger.error(f"❌ Text similarity search failed: {e}")
        
        return results
    
    async def _query_by_graph_traversal(self, seed_concept_ids: List[str], max_results: int) -> List[ConceptQueryResult]:
        """Query by traversing graph connections"""
        results = []
        
        if not NETWORKX_AVAILABLE or not self.graph:
            # Fallback to direct connections
            visited = set()
            for concept_id in seed_concept_ids:
                if concept_id in self.nodes:
                    for connected_id in self.nodes[concept_id].connections:
                        if connected_id not in visited and connected_id in self.nodes:
                            visited.add(connected_id)
                            node = self.nodes[connected_id]
                            results.append(ConceptQueryResult(
                                text=node.text,
                                source=node.source,
                                relevance=0.4,  # Lower relevance for connected nodes
                                concept_id=node.concept_id,
                                node_type=node.node_type,
                                connections=list(node.connections)
                            ))
            return results[:max_results]
        
        try:
            # Use NetworkX for more sophisticated graph traversal
            visited = set()
            for seed_id in seed_concept_ids:
                if seed_id in self.graph:
                    # Get neighbors within distance 2
                    neighbors = nx.single_source_shortest_path_length(
                        self.graph, seed_id, cutoff=2
                    )
                    
                    for neighbor_id, distance in neighbors.items():
                        if neighbor_id not in visited and neighbor_id != seed_id:
                            visited.add(neighbor_id)
                            node = self.nodes[neighbor_id]
                            
                            # Decrease relevance based on graph distance
                            relevance = 0.5 / (distance + 1)
                            
                            results.append(ConceptQueryResult(
                                text=node.text,
                                source=node.source,
                                relevance=relevance,
                                concept_id=node.concept_id,
                                node_type=node.node_type,
                                connections=list(node.connections)
                            ))
            
        except Exception as e:
            logger.error(f"❌ Graph traversal failed: {e}")
        
        return results[:max_results]
    
    def _deduplicate_and_rank_results(
        self, 
        results: List[ConceptQueryResult], 
        query: str
    ) -> List[ConceptQueryResult]:
        """Remove duplicates and rank results by relevance"""
        # Remove duplicates by concept_id
        seen_ids = set()
        unique_results = []
        
        for result in results:
            if result.concept_id not in seen_ids:
                seen_ids.add(result.concept_id)
                unique_results.append(result)
        
        # Enhance relevance scores
        query_words = set(query.lower().split())
        for result in unique_results:
            # Boost relevance if query words appear in text
            text_words = set(result.text.lower().split())
            word_overlap = len(query_words.intersection(text_words))
            if word_overlap > 0:
                overlap_boost = (word_overlap / len(query_words)) * 0.2
                result.relevance = min(1.0, result.relevance + overlap_boost)
        
        # Sort by relevance (descending)
        unique_results.sort(key=lambda r: r.relevance, reverse=True)
        
        return unique_results
    
    async def add_concept(
        self,
        name: str,
        text: str,
        source: str,
        node_type: str = "concept",
        metadata: Optional[Dict[str, Any]] = None,
        connections: Optional[List[str]] = None
    ) -> str:
        """Add a new concept to the mesh"""
        try:
            concept_id = f"concept_{len(self.nodes)}_{int(time.time())}"
            
            node = ConceptNode(
                concept_id=concept_id,
                name=name,
                text=text,
                source=source,
                node_type=node_type,
                created_at=datetime.now(),
                metadata=metadata or {},
                connections=set(connections or [])
            )
            
            self.nodes[concept_id] = node
            
            # Add to graph
            if self.graph:
                self.graph.add_node(concept_id, **node.metadata)
                for connection in node.connections:
                    if connection in self.nodes:
                        self.graph.add_edge(concept_id, connection)
            
            # Rebuild search index if needed (for now, just log)
            logger.info(f"➕ Added concept: {name}")
            
            return concept_id
            
        except Exception as e:
            logger.error(f"❌ Failed to add concept: {e}")
            raise
    
    async def save_snapshot(self):
        """Save current Concept Mesh to snapshot file"""
        try:
            logger.info(f"💾 Saving Concept Mesh snapshot: {self.snapshot_path}")
            
            snapshot_data = {
                "nodes": self.nodes,
                "embedding_index": self.embedding_index,
                "embeddings": self.embeddings,
                "timestamp": datetime.now(),
                "stats": {
                    "node_count": len(self.nodes),
                    "query_count": self.query_count
                }
            }
            
            with open(self.snapshot_path, 'wb') as f:
                pickle.dump(snapshot_data, f)
            
            self.last_snapshot_time = datetime.now()
            logger.info("✅ Snapshot saved")
            
        except Exception as e:
            logger.error(f"❌ Failed to save snapshot: {e}")
    
    async def health_check(self) -> bool:
        """Check health of Concept Mesh system"""
        return len(self.nodes) > 0
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get Concept Mesh statistics"""
        return {
            "node_count": len(self.nodes),
            "graph_edges": self.graph.number_of_edges() if self.graph else 0,
            "query_count": self.query_count,
            "total_query_time": self.total_query_time,
            "average_query_time": (
                self.total_query_time / self.query_count 
                if self.query_count > 0 else 0
            ),
            "last_snapshot": self.last_snapshot_time.isoformat() if self.last_snapshot_time else None,
            "search_index_ready": self.tfidf_vectorizer is not None
        }
    
    async def cleanup(self):
        """Cleanup Concept Mesh resources"""
        # Save snapshot before cleanup
        await self.save_snapshot()
        
        # Clear data structures
        self.nodes.clear()
        if self.graph:
            self.graph.clear()
        
        self.embeddings = None
        self.tfidf_matrix = None
        self.tfidf_vectorizer = None
        
        logger.info("🧹 Concept Mesh cleaned up")

if __name__ == "__main__":
    # Demo Concept Mesh
    async def demo_concept_mesh():
        mesh = ConceptMeshAPI()
        await mesh.initialize()
        
        # Test query
        results = await mesh.query_concepts(
            query="What is quantum phase dynamics?",
            concepts=["quantum", "phase", "dynamics"]
        )
        
        for result in results:
            print(f"Concept: {result.text[:100]}...")
            print(f"Source: {result.source}, Relevance: {result.relevance}")
            print(f"Type: {result.node_type}, ID: {result.concept_id}")
            print("---")
        
        # Test adding concept
        new_id = await mesh.add_concept(
            name="Demo Concept",
            text="This is a demo concept added to the mesh.",
            source="demo_script",
            node_type="demo"
        )
        print(f"Added concept with ID: {new_id}")
        
        await mesh.cleanup()
    
    asyncio.run(demo_concept_mesh())

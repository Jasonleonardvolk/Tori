"""
Context Builder: Memory Integration for Prajna
==============================================

This module builds context for Prajna by retrieving relevant information from:
1. Soliton Memory (personal/conversation memory with phase dynamics)
2. Concept Mesh (knowledge graph from PDFs, videos, images, etc.)

The context builder ensures Prajna only speaks from known, ingested knowledge.
All retrieved content is traceable back to specific sources in TORI's memory.
"""

import asyncio
import logging
import time
from typing import List, Optional, Dict, Any, Set
from dataclasses import dataclass
from datetime import datetime

# Import memory interfaces
from .soliton_interface import SolitonMemoryInterface
from .concept_mesh_api import ConceptMeshAPI

logger = logging.getLogger("prajna.context")

@dataclass
class MemorySnippet:
    """A piece of retrieved memory with metadata"""
    text: str
    source: str
    relevance_score: float
    timestamp: Optional[datetime] = None
    memory_type: str = "unknown"  # "soliton", "concept", "hybrid"
    phase_signature: Optional[Dict[str, float]] = None

@dataclass
class ContextResult:
    """Complete context package for Prajna"""
    text: str                    # Combined context text
    sources: List[str]           # Source references
    snippets: List[MemorySnippet] # Individual memory pieces
    total_relevance: float       # Aggregate relevance score
    retrieval_time: float        # Time taken to build context
    concept_coverage: Set[str]   # Concepts covered in context

class ContextBuilder:
    """
    Builds comprehensive context for Prajna from TORI's memory systems
    """
    
    def __init__(
        self,
        max_context_length: int = 2048,
        max_snippets: int = 10,
        relevance_threshold: float = 0.3,
        temporal_decay: float = 0.1
    ):
        self.max_context_length = max_context_length
        self.max_snippets = max_snippets
        self.relevance_threshold = relevance_threshold
        self.temporal_decay = temporal_decay
        
    async def build_context(
        self,
        user_query: str,
        focus_concept: Optional[str] = None,
        conversation_id: Optional[str] = None,
        soliton_memory: Optional[SolitonMemoryInterface] = None,
        concept_mesh: Optional[ConceptMeshAPI] = None
    ) -> ContextResult:
        """
        Build comprehensive context for Prajna from all TORI memory sources
        """
        start_time = time.time()
        
        try:
            logger.info(f"🔍 Building context for: {user_query[:100]}...")
            
            # Step 1: Extract concepts from query
            concepts = self._extract_concepts(user_query, focus_concept)
            logger.info(f"📝 Extracted concepts: {concepts}")
            
            # Step 2: Retrieve from Soliton Memory (personal/conversation context)
            soliton_snippets = []
            if soliton_memory:
                soliton_snippets = await self._retrieve_soliton_memory(
                    query=user_query,
                    concepts=concepts,
                    conversation_id=conversation_id,
                    soliton=soliton_memory
                )
            
            # Step 3: Retrieve from Concept Mesh (knowledge graph)
            mesh_snippets = []
            if concept_mesh:
                mesh_snippets = await self._retrieve_concept_mesh(
                    query=user_query,
                    concepts=concepts,
                    mesh=concept_mesh
                )
            
            # Step 4: Merge and rank all snippets
            all_snippets = soliton_snippets + mesh_snippets
            ranked_snippets = self._rank_and_filter_snippets(
                snippets=all_snippets,
                query=user_query,
                concepts=concepts
            )
            
            # Step 5: Build final context text
            context_text, selected_snippets = self._build_context_text(ranked_snippets)
            
            # Step 6: Compile results
            sources = list(set(snippet.source for snippet in selected_snippets))
            total_relevance = sum(snippet.relevance_score for snippet in selected_snippets)
            concept_coverage = set(concepts)
            
            retrieval_time = time.time() - start_time
            
            logger.info(f"✅ Context built: {len(selected_snippets)} snippets, {len(context_text)} chars, {retrieval_time:.2f}s")
            
            return ContextResult(
                text=context_text,
                sources=sources,
                snippets=selected_snippets,
                total_relevance=total_relevance,
                retrieval_time=retrieval_time,
                concept_coverage=concept_coverage
            )
            
        except Exception as e:
            logger.error(f"❌ Context building failed: {e}")
            # Return empty context rather than failing
            return ContextResult(
                text="No relevant context found in TORI's memory.",
                sources=["TORI_FALLBACK"],
                snippets=[],
                total_relevance=0.0,
                retrieval_time=time.time() - start_time,
                concept_coverage=set()
            )
    
    def _extract_concepts(self, query: str, focus_concept: Optional[str] = None) -> List[str]:
        """Extract key concepts from the user query"""
        concepts = []
        
        # Add explicit focus concept
        if focus_concept:
            concepts.append(focus_concept.lower())
        
        # Simple keyword extraction (can be enhanced with NLP)
        words = query.lower().split()
        
        # Filter out stopwords and extract meaningful terms
        stopwords = {
            "what", "is", "the", "and", "or", "of", "in", "a", "to", "how", 
            "why", "when", "where", "who", "can", "could", "should", "would",
            "i", "me", "my", "you", "your", "it", "its", "that", "this",
            "with", "for", "from", "by", "about", "into", "through", "during"
        }
        
        keywords = [
            word.strip("?,.!;:()[]{}\"'") 
            for word in words 
            if len(word) > 2 and word.lower() not in stopwords
        ]
        
        concepts.extend(keywords)
        
        # Remove duplicates while preserving order
        seen = set()
        unique_concepts = []
        for concept in concepts:
            if concept not in seen:
                seen.add(concept)
                unique_concepts.append(concept)
        
        return unique_concepts
    
    async def _retrieve_soliton_memory(
        self,
        query: str,
        concepts: List[str],
        conversation_id: Optional[str],
        soliton: SolitonMemoryInterface
    ) -> List[MemorySnippet]:
        """Retrieve relevant memories from Soliton Memory system"""
        try:
            logger.info("💾 Querying Soliton Memory...")
            
            # Query Soliton Memory with concepts and conversation context
            soliton_results = await soliton.query_memory(
                query=query,
                concepts=concepts,
                conversation_id=conversation_id,
                max_results=self.max_snippets // 2
            )
            
            snippets = []
            for result in soliton_results:
                snippet = MemorySnippet(
                    text=result.get("text", ""),
                    source=result.get("source", "soliton_memory"),
                    relevance_score=result.get("relevance", 0.5),
                    timestamp=result.get("timestamp"),
                    memory_type="soliton",
                    phase_signature=result.get("phase_signature")
                )
                snippets.append(snippet)
            
            logger.info(f"💾 Retrieved {len(snippets)} Soliton memory snippets")
            return snippets
            
        except Exception as e:
            logger.error(f"❌ Soliton memory retrieval failed: {e}")
            return []
    
    async def _retrieve_concept_mesh(
        self,
        query: str,
        concepts: List[str],
        mesh: ConceptMeshAPI
    ) -> List[MemorySnippet]:
        """Retrieve relevant knowledge from Concept Mesh"""
        try:
            logger.info("🕸️ Querying Concept Mesh...")
            
            # Query Concept Mesh for relevant knowledge nodes
            mesh_results = await mesh.query_concepts(
                query=query,
                concepts=concepts,
                max_results=self.max_snippets // 2
            )
            
            snippets = []
            for result in mesh_results:
                snippet = MemorySnippet(
                    text=result.get("text", ""),
                    source=result.get("source", "concept_mesh"),
                    relevance_score=result.get("relevance", 0.5),
                    timestamp=result.get("created_at"),
                    memory_type="concept"
                )
                snippets.append(snippet)
            
            logger.info(f"🕸️ Retrieved {len(snippets)} Concept Mesh snippets")
            return snippets
            
        except Exception as e:
            logger.error(f"❌ Concept mesh retrieval failed: {e}")
            return []
    
    def _rank_and_filter_snippets(
        self,
        snippets: List[MemorySnippet],
        query: str,
        concepts: List[str]
    ) -> List[MemorySnippet]:
        """Rank snippets by relevance and filter out low-quality ones"""
        
        # Apply relevance threshold
        filtered_snippets = [
            snippet for snippet in snippets 
            if snippet.relevance_score >= self.relevance_threshold
        ]
        
        # Enhance relevance scores based on multiple factors
        for snippet in filtered_snippets:
            snippet.relevance_score = self._calculate_enhanced_relevance(
                snippet, query, concepts
            )
        
        # Sort by relevance (descending)
        ranked_snippets = sorted(
            filtered_snippets,
            key=lambda s: s.relevance_score,
            reverse=True
        )
        
        # Limit to max snippets
        return ranked_snippets[:self.max_snippets]
    
    def _calculate_enhanced_relevance(
        self,
        snippet: MemorySnippet,
        query: str,
        concepts: List[str]
    ) -> float:
        """Calculate enhanced relevance score for a snippet"""
        base_score = snippet.relevance_score
        
        # Concept overlap bonus
        snippet_text_lower = snippet.text.lower()
        concept_matches = sum(1 for concept in concepts if concept in snippet_text_lower)
        concept_bonus = (concept_matches / len(concepts)) * 0.2 if concepts else 0
        
        # Query term overlap bonus
        query_words = set(query.lower().split())
        snippet_words = set(snippet_text_lower.split())
        overlap = len(query_words.intersection(snippet_words))
        query_bonus = (overlap / len(query_words)) * 0.1 if query_words else 0
        
        # Temporal decay (more recent = higher relevance)
        temporal_bonus = 0.0
        if snippet.timestamp:
            hours_ago = (datetime.now() - snippet.timestamp).total_seconds() / 3600
            temporal_bonus = max(0, 0.1 * (1 - hours_ago * self.temporal_decay))
        
        # Memory type preference (slight preference for recent conversations)
        type_bonus = 0.05 if snippet.memory_type == "soliton" else 0.0
        
        # Calculate final score
        enhanced_score = base_score + concept_bonus + query_bonus + temporal_bonus + type_bonus
        
        return min(1.0, enhanced_score)  # Cap at 1.0
    
    def _build_context_text(self, snippets: List[MemorySnippet]) -> tuple[str, List[MemorySnippet]]:
        """Build the final context text from selected snippets"""
        context_parts = []
        selected_snippets = []
        current_length = 0
        
        for snippet in snippets:
            # Check if adding this snippet would exceed length limit
            snippet_length = len(snippet.text)
            if current_length + snippet_length > self.max_context_length:
                # Try to truncate if it's the first snippet
                if not context_parts:
                    truncated_text = snippet.text[:self.max_context_length - 100] + "..."
                    context_parts.append(f"[{snippet.source}]: {truncated_text}")
                    selected_snippets.append(snippet)
                break
            
            # Add snippet to context
            context_parts.append(f"[{snippet.source}]: {snippet.text}")
            selected_snippets.append(snippet)
            current_length += snippet_length + len(snippet.source) + 4  # Account for formatting
        
        # Join all parts
        context_text = "\n\n".join(context_parts)
        
        return context_text, selected_snippets

# Global function for easy access
async def build_context(
    user_query: str,
    focus_concept: Optional[str] = None,
    conversation_id: Optional[str] = None,
    soliton_memory: Optional[SolitonMemoryInterface] = None,
    concept_mesh: Optional[ConceptMeshAPI] = None
) -> ContextResult:
    """
    Build context for Prajna from TORI's memory systems
    
    This is the main entry point for context building.
    """
    builder = ContextBuilder()
    return await builder.build_context(
        user_query=user_query,
        focus_concept=focus_concept,
        conversation_id=conversation_id,
        soliton_memory=soliton_memory,
        concept_mesh=concept_mesh
    )

if __name__ == "__main__":
    # Demo context building
    async def demo_context():
        # Mock memory interfaces for testing
        result = await build_context(
            user_query="What is quantum phase dynamics?",
            focus_concept="quantum",
            soliton_memory=None,  # Would be real interface in production
            concept_mesh=None     # Would be real interface in production
        )
        
        print(f"Context: {result.text[:200]}...")
        print(f"Sources: {result.sources}")
        print(f"Retrieval time: {result.retrieval_time:.2f}s")
    
    asyncio.run(demo_context())

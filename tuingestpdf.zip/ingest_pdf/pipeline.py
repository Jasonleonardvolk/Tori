from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
import numpy as np
import json
import os
import hashlib
import PyPDF2
import logging
from datetime import datetime

# Import all enhanced modules (addresses all Issues #1-#4)
from .extract_blocks import extract_concept_blocks
from .features import build_feature_matrix
from .spectral import spectral_embed
from .clustering import run_oscillator_clustering, cluster_cohesion
from .scoring import (
    score_clusters, resonance_score, narrative_centrality, build_cluster_adjacency, 
    filter_concepts, apply_confidence_fallback, calculate_concept_confidence
)
from .keywords import extract_keywords
from .models import ConceptTuple, ConceptExtractionResult, create_concept_tuple_from_dict
from .persistence import save_concepts, save_extraction_result
from .lyapunov import concept_predictability, document_chaos_profile
from .source_validator import validate_source, SourceValidationResult
from .memory_gating import apply_memory_gating
from .phase_walk import PhaseCoherentWalk
from .pipeline_validator import validate_concepts
from .concept_logger import (
    default_concept_logger as concept_logger, 
    log_loop_record, log_concept_summary, warn_empty_segment
)
from .threshold_config import (
    MIN_CONFIDENCE, FALLBACK_MIN_COUNT, MAX_CONCEPTS_DEFAULT,
    get_threshold_for_media_type, get_adaptive_threshold, get_fallback_count
)
from .cognitive_interface import add_concept_diff  # 🔧 FIXED IMPORT
from .extractConceptsFromDocument import extractConceptsFromDocument  # 🌍 Universal extraction

# Configure logging
logger = logging.getLogger("pdf_ingestion")
logger.setLevel(logging.INFO)

# 🌍 UNIVERSAL CONCEPT DATABASE - Load main database + universal seeds
concept_db_path = Path(__file__).parent / "data" / "concept_database.json"
universal_seed_path = Path(__file__).parent / "data" / "concept_seed_universal.json"
concept_database = []
concept_names = []
concept_scores = {}

def load_universal_concept_database():
    """🌍 Load and merge main concept database with universal seeds"""
    global concept_database, concept_names, concept_scores
    
    # Load main concept database
    main_concepts = []
    try:
        with open(concept_db_path, "r", encoding="utf-8") as f:
            main_concepts = json.load(f)
        logger.info(f"✅ Main concept database loaded: {len(main_concepts)} concepts")
    except Exception as e:
        logger.warning(f"⚠️ Failed to load main concept database: {e}")
        main_concepts = []
    
    # Load universal seed concepts
    universal_seeds = []
    try:
        with open(universal_seed_path, "r", encoding="utf-8") as f:
            universal_seeds = json.load(f)
        logger.info(f"🌍 Universal seed concepts loaded: {len(universal_seeds)} concepts")
    except Exception as e:
        logger.warning(f"⚠️ Failed to load universal seed concepts: {e}")
        universal_seeds = []
    
    # Merge databases (avoid duplicates)
    existing_names = {c["name"].lower() for c in main_concepts}
    merged_concepts = main_concepts.copy()
    
    seeds_added = 0
    for seed in universal_seeds:
        if seed["name"].lower() not in existing_names:
            merged_concepts.append(seed)
            seeds_added += 1
    
    # Update global variables
    concept_database = merged_concepts
    concept_names = [c["name"] for c in concept_database]
    concept_scores = {c["name"]: c["priority"] for c in concept_database}
    
    # Log domain breakdown
    domains = {}
    for concept in concept_database:
        domain = concept.get("category", "general")
        domains[domain] = domains.get(domain, 0) + 1
    
    logger.info(f"🌍 UNIVERSAL DATABASE READY: {len(concept_database)} total concepts")
    logger.info(f"📊 Added {seeds_added} universal seed concepts")
    logger.info(f"📊 Domain coverage: {dict(sorted(domains.items()))}")

# Load the universal database
load_universal_concept_database()

def auto_prefill_concept_db(extracted_concepts: List[Dict[str, Any]], document_name: str = "") -> int:
    """
    🧬 AUTO-PREFILL CONCEPT DATABASE - Now with universal coverage
    
    Automatically adds high-quality extracted concepts to the concept database
    for future boosting across ALL domains.
    """
    global concept_database, concept_names, concept_scores
    
    logger.info(f"📥 UNIVERSAL AUTO-PREFILL: Analyzing {len(extracted_concepts)} concepts from {document_name}")
    
    # Get existing concept names (case-insensitive)
    existing_names = {c["name"].lower() for c in concept_database}
    
    new_concepts = []
    prefill_threshold = 0.5  # Only auto-add concepts with score >= 0.5
    
    for concept in extracted_concepts:
        concept_name = concept.get("name", "")
        concept_score = concept.get("score", 0.0)
        concept_method = concept.get("method", "")
        
        # Skip debug/fallback concepts
        if "debug" in concept_method or "fallback" in concept_method:
            continue
            
        # Skip generic concepts
        generic_terms = ["document", "file", "text", "content", "paper", "analysis"]
        if any(generic in concept_name.lower() for generic in generic_terms):
            continue
        
        # Check if concept meets auto-prefill criteria
        if (concept_score >= prefill_threshold and 
            concept_name.lower() not in existing_names and
            len(concept_name) > 3 and  # Skip very short names
            concept_name.replace(" ", "").replace("-", "").isalpha()):  # Skip numeric/special chars
            
            # Determine category based on method and content
            category = "auto_discovered"
            
            # Enhanced domain detection
            name_lower = concept_name.lower()
            if any(term in name_lower for term in ["quantum", "particle", "field", "wave", "energy", "relativity"]):
                category = "Physics"
            elif any(term in name_lower for term in ["gene", "dna", "protein", "cell", "evolution", "biology"]):
                category = "Biology"
            elif any(term in name_lower for term in ["algorithm", "computing", "neural", "machine", "ai"]):
                category = "Computer Science"
            elif any(term in name_lower for term in ["philosophy", "epistemology", "ontology", "phenomenology"]):
                category = "Philosophy"
            elif any(term in name_lower for term in ["literature", "narrative", "poetry", "novel", "literary"]):
                category = "Literature"
            elif any(term in name_lower for term in ["art", "painting", "sculpture", "aesthetic", "visual"]):
                category = "Art"
            elif any(term in name_lower for term in ["music", "harmony", "rhythm", "composition", "musical"]):
                category = "Music"
            elif any(term in name_lower for term in ["mathematical", "theorem", "proof", "algebra", "geometry"]):
                category = "Mathematics"
            elif "universal" in concept_method:
                category = "universal_extraction"
            
            # Generate meaningful aliases
            aliases = []
            name_parts = concept_name.lower().split()
            if len(name_parts) > 1:
                # Add abbreviated forms
                if len(name_parts) == 2:
                    abbrev = f"{name_parts[0][0]}{name_parts[1][0]}".upper()
                    if len(abbrev) >= 2:
                        aliases.append(abbrev)
                
                # Add individual significant words
                for part in name_parts:
                    if len(part) > 4 and part not in ["theory", "method", "analysis", "study"]:
                        aliases.append(part)
            
            # Determine boost multiplier based on extraction method and score
            boost_multiplier = 1.2  # Default
            if "keybert" in concept_method.lower():
                boost_multiplier = 1.25  # Semantic relevance bonus
            if "ner" in concept_method.lower():
                boost_multiplier = 1.3   # Named entity bonus
            if concept_score > 0.8:
                boost_multiplier += 0.1  # High confidence bonus
            
            new_concept = {
                "name": concept_name,
                "priority": min(0.95, concept_score),  # Cap at 0.95
                "category": category,
                "aliases": aliases,
                "boost_multiplier": boost_multiplier,
                "source": {
                    "auto_prefill": True,
                    "universal_extraction": True,
                    "document": document_name,
                    "extraction_method": concept_method,
                    "original_score": concept_score,
                    "discovery_date": datetime.now().isoformat(),
                    "domain_detected": category
                }
            }
            
            new_concepts.append(new_concept)
            logger.info(f"📥 UNIVERSAL PREFILL CANDIDATE: {concept_name} (score: {concept_score:.3f}, domain: {category})")
    
    # Add new concepts to database
    if new_concepts:
        concept_database.extend(new_concepts)
        
        # Update in-memory indexes
        concept_names.extend([c["name"] for c in new_concepts])
        concept_scores.update({c["name"]: c["priority"] for c in new_concepts})
        
        # Write updated database back to disk
        try:
            with open(concept_db_path, "w", encoding="utf-8") as f:
                json.dump(concept_database, f, indent=2, ensure_ascii=False)
            
            logger.info(f"📥 UNIVERSAL AUTO-PREFILL SUCCESS: Added {len(new_concepts)} new concepts to database")
            logger.info(f"📊 Database now contains {len(concept_database)} total concepts")
            
            # Log domain breakdown of new concepts
            new_domains = {}
            for concept in new_concepts:
                domain = concept.get("category", "general")
                new_domains[domain] = new_domains.get(domain, 0) + 1
            
            logger.info(f"📊 New concepts by domain: {new_domains}")
            
            # Log sample new concepts for visibility
            for i, concept in enumerate(new_concepts[:3], 1):
                logger.info(f"  ✅ {i}. {concept['name']} (priority: {concept['priority']:.3f}, domain: {concept['category']})")
            if len(new_concepts) > 3:
                logger.info(f"  ... and {len(new_concepts) - 3} more")
                
        except Exception as e:
            logger.error(f"❌ UNIVERSAL AUTO-PREFILL FAILED: Could not write to concept database: {e}")
            # Rollback in-memory changes
            concept_database = concept_database[:-len(new_concepts)]
            for c in new_concepts:
                if c["name"] in concept_names:
                    concept_names.remove(c["name"])
                if c["name"] in concept_scores:
                    del concept_scores[c["name"]]
            return 0
            
    else:
        logger.info(f"📥 UNIVERSAL AUTO-PREFILL: No new concepts met prefill criteria (threshold: {prefill_threshold})")
    
    return len(new_concepts)

def boost_known_concepts(chunk: str) -> List[Dict[str, Any]]:
    """🌍 UNIVERSAL CONCEPT BOOSTING - Enhanced with cross-domain coverage"""
    boosted = []
    chunk_lower = chunk.lower()
    
    # 🔬 SURGICAL DEBUG: Log what we're checking against
    logger.info(f"🔍 UNIVERSAL BOOST: Checking chunk ({len(chunk)} chars) against {len(concept_database)} database concepts")
    logger.info(f"🔍 First 200 chars of chunk: {chunk[:200]}")
    
    domain_matches = {}
    
    for concept in concept_database:
        name = concept["name"]
        aliases = concept.get("aliases", [])
        all_terms = [name.lower()] + [alias.lower() for alias in aliases]
        
        # Check if any term appears in chunk
        matched_terms = [term for term in all_terms if term in chunk_lower]
        
        if matched_terms:
            # 🧬 ENHANCED SCORING: Apply boost multiplier from database
            base_score = concept_scores[name]
            boost_multiplier = concept.get("boost_multiplier", 1.2)
            boosted_score = min(0.98, base_score * boost_multiplier)
            
            # Additional boost for universal seed concepts
            if concept.get("source", {}).get("universal_seed", False):
                boosted_score = min(0.99, boosted_score * 1.05)  # Small seed bonus
            
            category = concept.get("category", "general")
            domain_matches[category] = domain_matches.get(category, 0) + 1
            
            boosted.append({
                "name": name,
                "score": boosted_score,
                "method": "universal_database_boosted",
                "source": {
                    "database_matched": True, 
                    "matched_terms": matched_terms,
                    "universal_database": True,
                    "domain": category
                },
                "context": f"Universal database match: {matched_terms[0]} found in text",
                "metadata": {
                    "category": category,
                    "aliases": aliases,
                    "boost_multiplier": boost_multiplier,
                    "original_score": base_score,
                    "boosted_score": boosted_score,
                    "matched_terms": matched_terms,
                    "universal_seed": concept.get("source", {}).get("universal_seed", False)
                }
            })
            logger.info(f"🚀 Universal boost: {name} ({base_score:.3f} → {boosted_score:.3f}, domain: {category})")
    
    if domain_matches:
        logger.info(f"🌍 Domain matches found: {domain_matches}")
    
    logger.info(f"🚀 Universal database boosting result: {len(boosted)} concepts found")
    return boosted

def extract_and_boost_concepts(chunk: str, threshold: float = 0.0) -> List[Dict[str, Any]]:
    """🌍 UNIVERSAL EXTRACT AND BOOST - Zero threshold, maximum coverage"""
    logger.info(f"🔧 🌍 UNIVERSAL EXTRACT AND BOOST: threshold: {threshold}")
    logger.info(f"🔬 Chunk length: {len(chunk)} chars")
    logger.info(f"🔬 First 300 chars: {chunk[:300]}")
    
    # Extract concepts using universal method
    logger.info("🔬 STEP 1: Calling universal extractConceptsFromDocument...")
    semantic_hits = extractConceptsFromDocument(chunk, threshold=threshold)
    logger.info(f"📊 UNIVERSAL SEMANTIC EXTRACTION RESULT: {len(semantic_hits)} concepts")
    
    # 🔬 LOG RAW CONCEPTS
    if semantic_hits:
        logger.info("📊 RAW UNIVERSAL CONCEPTS (pre-boost):")
        for i, c in enumerate(semantic_hits[:10], 1):  # Show first 10
            method = c.get('method', 'unknown')
            score = c.get('score', 0)
            logger.info(f"  {i:2}. {c['name']} (score: {score:.3f}, method: {method})")
        if len(semantic_hits) > 10:
            logger.info(f"  ... and {len(semantic_hits) - 10} more concepts")
    else:
        logger.warning("❌ ZERO universal concepts extracted from chunk!")
        logger.warning(f"❌ Chunk analysis: {len(chunk.split())} words, {len([w for w in chunk.split() if len(w) > 4])} significant")
    
    # Apply universal database boosting
    logger.info("🔬 STEP 2: Calling universal boost_known_concepts...")
    boosted = boost_known_concepts(chunk)
    logger.info(f"🚀 UNIVERSAL DATABASE BOOST RESULT: {len(boosted)} concepts")
    
    # Combine results
    combined = semantic_hits + boosted
    logger.info(f"🔧 UNIVERSAL COMBINED RESULT: {len(combined)} total concepts")
    
    # 🧬 CROSS-REFERENCE BOOST: Additional scoring for concepts found by both methods
    concept_names_lower = {c["name"].lower(): c for c in combined}
    duplicates_found = {}
    
    for concept in combined:
        name_lower = concept["name"].lower()
        if name_lower in duplicates_found:
            duplicates_found[name_lower].append(concept)
        else:
            duplicates_found[name_lower] = [concept]
    
    # Apply cross-reference boosting
    for name_lower, concept_list in duplicates_found.items():
        if len(concept_list) > 1:
            # Found by multiple methods - boost the highest scoring one
            best_concept = max(concept_list, key=lambda x: x["score"])
            original_score = best_concept["score"]
            best_concept["score"] = min(0.95, original_score * 1.15)  # 15% cross-reference boost
            best_concept["metadata"] = best_concept.get("metadata", {})
            best_concept["metadata"]["cross_reference_boost"] = True
            best_concept["metadata"]["methods_found"] = len(concept_list)
            
            logger.info(f"🎯 Cross-reference boost: {best_concept['name']} ({original_score:.3f} → {best_concept['score']:.3f})")
            
            # Remove duplicates, keep only the best one
            for concept in concept_list:
                if concept != best_concept and concept in combined:
                    combined.remove(concept)
    
    logger.info(f"🔧 FINAL UNIVERSAL EXTRACTION: {len(combined)} concepts after deduplication")
    
    # 🔬 LOG FINAL RESULTS
    if combined:
        logger.info("✅ FINAL UNIVERSAL CONCEPTS TO BE INJECTED:")
        method_counts = {}
        for i, c in enumerate(combined[:15], 1):  # Show first 15
            method = c.get('method', 'unknown')
            score = c.get('score', 0)
            boost_flag = "🎯" if c.get('metadata', {}).get('cross_reference_boost', False) else ""
            domain = c.get('source', {}).get('domain', c.get('metadata', {}).get('category', ''))
            domain_str = f" [{domain}]" if domain else ""
            logger.info(f"  {i:2}. {c['name']} (score: {score:.3f}, method: {method}){domain_str} {boost_flag}")
            
            method_counts[method] = method_counts.get(method, 0) + 1
        
        if len(combined) > 15:
            logger.info(f"  ... and {len(combined) - 15} more concepts")
        
        logger.info(f"📊 Method distribution: {method_counts}")
    
    return combined

def extract_chunks(pdf_path: str) -> List[str]:
    """Extract text chunks from PDF for processing with debugging"""
    try:
        chunks = extract_concept_blocks(pdf_path)
        logger.info(f"📄 Extracted {len(chunks)} chunks from {Path(pdf_path).name}")
        
        # 🔬 DEBUG: Log chunk sizes and sample content
        for i, chunk in enumerate(chunks[:3], 1):  # Show first 3 chunks
            logger.info(f"🔬 Chunk {i}: {len(chunk)} chars, preview: {chunk[:100]}...")
        
        return chunks
    except Exception as e:
        logger.error(f"Failed to extract chunks from {pdf_path}: {e}")
        return []

def extract_pdf_metadata(pdf_path: str) -> Dict[str, Any]:
    """Extract comprehensive metadata from PDF file for source provenance tracking."""
    metadata = {
        "filename": Path(pdf_path).name,
        "file_path": pdf_path,
        "extraction_timestamp": datetime.now().isoformat(),
        "extractor_version": "universal_pipeline_v1.0"
    }
    
    try:
        with open(pdf_path, "rb") as f:
            file_content = f.read()
            metadata["sha256"] = hashlib.sha256(file_content).hexdigest()
            metadata["file_size_bytes"] = len(file_content)
    except Exception as e:
        logger.warning(f"Could not calculate file hash: {e}")

    try:
        with open(pdf_path, "rb") as f:
            pdf = PyPDF2.PdfReader(f)
            if pdf.metadata:
                metadata["pdf_metadata"] = {
                    k.lower().replace('/', ''): str(v)
                    for k, v in pdf.metadata.items() if k and v
                }
            metadata["page_count"] = len(pdf.pages)
    except Exception as e:
        logger.warning(f"Could not extract PDF metadata: {e}")
    
    return metadata

def ingest_pdf_clean(pdf_path: str, doc_id: str = None, extraction_threshold: float = 0.0) -> Dict[str, Any]:
    """
    🌍 UNIVERSAL PDF INGESTION PIPELINE
    
    Now with universal concept extraction across all domains and enhanced auto-prefill.
    """
    start_time = datetime.now()
    
    if doc_id is None:
        doc_id = Path(pdf_path).stem
    
    logger.info(f"🚀 🌍 UNIVERSAL PDF INGESTION: {Path(pdf_path).name}")
    logger.info(f"🔬 ZERO THRESHOLD MODE: {extraction_threshold} (maximum coverage)")
    logger.info("🌍 UNIVERSAL PIPELINE: Cross-domain concept extraction enabled")
    logger.info(f"📊 Database ready: {len(concept_database)} concepts across all domains")
    
    try:
        # Extract metadata for provenance
        doc_metadata = extract_pdf_metadata(pdf_path)
        
        # Extract chunks from PDF
        chunks = extract_chunks(pdf_path)
        if not chunks:
            logger.warning(f"⚠️ No chunks extracted from {pdf_path}")
            return {
                "filename": Path(pdf_path).name,
                "concept_count": 0,
                "status": "empty",
                "processing_time_seconds": (datetime.now() - start_time).total_seconds()
            }
        
        # 🌍 UNIVERSAL PROCESSING LOOP
        all_extracted_concepts = []
        semantic_count = 0
        boosted_count = 0
        cross_reference_boosted = 0
        universal_methods = set()
        domain_distribution = {}
        
        for i, chunk in enumerate(chunks):
            logger.info(f"🔬 =============== UNIVERSAL CHUNK {i+1}/{len(chunks)} ===============")
            logger.info(f"📊 Processing chunk {i+1}/{len(chunks)} ({len(chunk)} chars)")
            
            # 🌍 Apply universal extraction + boosting
            enhanced_concepts = extract_and_boost_concepts(chunk, threshold=extraction_threshold)
            
            # Count extraction types and track domains
            chunk_semantic = 0
            chunk_boosted = 0
            chunk_cross_ref = 0
            
            for c in enhanced_concepts:
                method = c.get("method", "")
                if "universal" in method:
                    chunk_semantic += 1
                    # Track universal extraction methods
                    if "yake" in method:
                        universal_methods.add("YAKE")
                    if "keybert" in method:
                        universal_methods.add("KeyBERT")
                    if "ner" in method:
                        universal_methods.add("NER")
                
                if "database_boosted" in method:
                    chunk_boosted += 1
                
                if c.get("metadata", {}).get("cross_reference_boost", False):
                    chunk_cross_ref += 1
                
                # Track domain distribution
                domain = (c.get("source", {}).get("domain") or 
                         c.get("metadata", {}).get("category") or 
                         "unknown")
                domain_distribution[domain] = domain_distribution.get(domain, 0) + 1
            
            semantic_count += chunk_semantic
            boosted_count += chunk_boosted
            cross_reference_boosted += chunk_cross_ref
            
            logger.info(f"🔬 CHUNK {i+1} RESULTS: {len(enhanced_concepts)} concepts")
            logger.info(f"   🌍 {chunk_semantic} universal extraction, 🚀 {chunk_boosted} boosted, 🎯 {chunk_cross_ref} cross-ref boosted")
            
            all_extracted_concepts.extend(enhanced_concepts)
            logger.info(f"🔬 =============== END CHUNK {i+1} ===============")
        
        if not all_extracted_concepts:
            logger.error("🔬 ❌ CRITICAL: NO CONCEPTS EXTRACTED WITH UNIVERSAL PIPELINE!")
            return {
                "filename": Path(pdf_path).name,
                "concept_count": 0,
                "status": "critical_failure",
                "processing_time_seconds": (datetime.now() - start_time).total_seconds()
            }
        
        # 🌍 UNIVERSAL AUTO-PREFILL
        logger.info("📥 RUNNING UNIVERSAL AUTO-PREFILL ANALYSIS...")
        prefill_count = auto_prefill_concept_db(all_extracted_concepts, Path(pdf_path).name)
        
        # 🧠 CONCEPTMESH INTEGRATION - 🔧 FIXED CALL SIGNATURE
        logger.info(f"🔬 INJECTING {len(all_extracted_concepts)} UNIVERSAL CONCEPTS INTO CONCEPTMESH")
        
        # 🔧 CRITICAL FIX: Use correct dictionary format for add_concept_diff
        concept_diff_data = {
            "type": "document",
            "title": Path(pdf_path).name,
            "concepts": all_extracted_concepts,
            "summary": f"Universal extraction found {len(all_extracted_concepts)} concepts using enhanced pipeline",
            "metadata": {
                "source": "universal_pdf_ingest",
                "filename": Path(pdf_path).name,
                "chunks_processed": len(chunks),
                "semantic_concepts": semantic_count,
                "boosted_concepts": boosted_count,
                "cross_reference_boosted": cross_reference_boosted,
                "auto_prefilled_concepts": prefill_count,
                "extraction_threshold": extraction_threshold,
                "extraction_timestamp": datetime.now().isoformat(),
                "processing_time_seconds": (datetime.now() - start_time).total_seconds(),
                "universal_pipeline": True,
                "universal_methods": list(universal_methods),
                "domain_distribution": domain_distribution
            }
        }
        
        add_concept_diff(concept_diff_data)  # 🔧 FIXED: Single dictionary parameter
        
        # Final summary
        processing_time = (datetime.now() - start_time).total_seconds()
        
        logger.info(f"✅ 🌍 UNIVERSAL PDF INGESTION COMPLETE: {Path(pdf_path).name}")
        logger.info(f"📊 FINAL RESULTS: {len(all_extracted_concepts)} total concepts")
        logger.info(f"   🌍 {semantic_count} universal semantic concepts")
        logger.info(f"   🚀 {boosted_count} database boosted concepts")
        logger.info(f"   🎯 {cross_reference_boosted} cross-reference boosted")
        logger.info(f"   📥 {prefill_count} concepts auto-prefilled to database")
        logger.info(f"   🧬 Universal methods used: {list(universal_methods)}")
        logger.info(f"   🌍 Domain distribution: {domain_distribution}")
        logger.info(f"⏱️ Processing time: {processing_time:.2f}s")
        logger.info(f"📊 Database now contains: {len(concept_database)} total concepts")
        
        return {
            "filename": Path(pdf_path).name,
            "concept_count": len(all_extracted_concepts),
            "concept_names": [c["name"] for c in all_extracted_concepts],
            "semantic_concepts": semantic_count,
            "boosted_concepts": boosted_count,
            "cross_reference_boosted": cross_reference_boosted,
            "auto_prefilled_concepts": prefill_count,
            "universal_methods": list(universal_methods),
            "domain_distribution": domain_distribution,
            "chunks_processed": len(chunks),
            "processing_time_seconds": processing_time,
            "extraction_threshold": extraction_threshold,
            "average_score": sum(c["score"] for c in all_extracted_concepts) / len(all_extracted_concepts),
            "high_confidence_concepts": sum(1 for c in all_extracted_concepts if c["score"] > 0.8),
            "concept_mesh_injected": True,
            "extraction_method": "universal_pipeline",
            "universal_pipeline": True,
            "database_size": len(concept_database),
            "status": "success"
        }
        
    except Exception as e:
        logger.exception(f"❌ Error during universal PDF ingestion: {str(e)}")
        return {
            "filename": Path(pdf_path).name,
            "concept_count": 0,
            "status": "error",
            "error_message": str(e),
            "processing_time_seconds": (datetime.now() - start_time).total_seconds()
        }

def batch_ingest_pdfs_clean(pdf_directory: str, extraction_threshold: float = 0.0) -> List[Dict[str, Any]]:
    """
    🌍 UNIVERSAL BATCH PROCESSING
    """
    pdf_dir = Path(pdf_directory)
    if not pdf_dir.exists():
        logger.error(f"PDF directory not found: {pdf_directory}")
        return []
    
    pdf_files = list(pdf_dir.glob("*.pdf"))
    if not pdf_files:
        logger.warning(f"No PDF files found in {pdf_directory}")
        return []
    
    logger.info(f"🚀 🌍 UNIVERSAL BATCH PROCESSING: {len(pdf_files)} PDFs")
    logger.info(f"📊 Universal database: {len(concept_database)} concepts ready")
    
    results = []
    total_concepts = 0
    total_boosted = 0
    total_cross_ref = 0
    total_prefilled = 0
    all_domains = {}
    all_methods = set()
    
    for i, pdf_path in enumerate(pdf_files):
        logger.info(f"📄 🌍 UNIVERSAL PDF {i+1}/{len(pdf_files)}: {pdf_path.name}")
        
        result = ingest_pdf_clean(str(pdf_path), extraction_threshold=extraction_threshold)
        result["batch_index"] = i + 1
        result["batch_total"] = len(pdf_files)
        
        # Track totals
        if result.get("status") == "success":
            total_concepts += result.get("concept_count", 0)
            total_boosted += result.get("boosted_concepts", 0)
            total_cross_ref += result.get("cross_reference_boosted", 0)
            total_prefilled += result.get("auto_prefilled_concepts", 0)
            
            # Aggregate domain distribution
            doc_domains = result.get("domain_distribution", {})
            for domain, count in doc_domains.items():
                all_domains[domain] = all_domains.get(domain, 0) + count
            
            # Aggregate methods
            doc_methods = result.get("universal_methods", [])
            all_methods.update(doc_methods)
        
        results.append(result)
        
        # Progress logging
        status = result.get("status", "unknown")
        concept_count = result.get("concept_count", 0)
        boosted_count = result.get("boosted_concepts", 0)
        prefill_count = result.get("auto_prefilled_concepts", 0)
        logger.info(f"✅ 🌍 Progress: {i+1}/{len(pdf_files)} - {status} - {concept_count} concepts (Boosted: {boosted_count}, Prefilled: {prefill_count})")
    
    successful = [r for r in results if r.get('status') == 'success']
    
    logger.info(f"🎯 🌍 UNIVERSAL BATCH COMPLETE:")
    logger.info(f"   📊 {len(successful)}/{len(pdf_files)} PDFs processed successfully")
    logger.info(f"   🧠 {total_concepts} total concepts extracted")
    logger.info(f"   🚀 {total_boosted} concepts database boosted")
    logger.info(f"   🎯 {total_cross_ref} concepts cross-reference boosted")
    logger.info(f"   📥 {total_prefilled} concepts auto-prefilled to database")
    logger.info(f"   🌍 Universal methods used: {list(all_methods)}")
    logger.info(f"   🌍 Domain distribution: {dict(sorted(all_domains.items()))}")
    logger.info(f"   📊 Final database size: {len(concept_database)} concepts")
    
    return results

# Legacy compatibility functions - updated for universal pipeline
def ingest_pdf_and_update_index(
    pdf_path: str,
    index_path: str,
    max_concepts: int = None,
    dim: int = 16,
    json_out: str = None,
    min_quality_score: float = 0.6,
    apply_gating: bool = True,
    coherence_threshold: float = 0.7,
    use_enhanced_extraction: bool = True,
    use_adaptive_thresholds: bool = True,
    save_full_results: bool = True,
    diagnostic_mode: bool = False,
    extraction_threshold: float = 0.0  # Universal: Zero threshold
) -> dict:
    """
    Legacy function - forwards to universal pipeline implementation.
    """
    logger.info(f"🔄 🌍 Legacy function called - forwarding to UNIVERSAL PIPELINE")
    result = ingest_pdf_clean(pdf_path, extraction_threshold=extraction_threshold)
    
    # Add legacy-expected fields
    result["extraction_method"] = "universal_pipeline"
    result["universal_pipeline_applied"] = True
    result["concept_database_updated"] = result.get("auto_prefilled_concepts", 0) > 0
    
    return result

# Export functions
__all__ = [
    'ingest_pdf_clean',
    'batch_ingest_pdfs_clean', 
    'extract_and_boost_concepts',
    'boost_known_concepts',
    'auto_prefill_concept_db',
    'load_universal_concept_database',
    'extractConceptsFromDocument',
    'ingest_pdf_and_update_index'  # Legacy compatibility
]

logger.info(f"🌍 🧬 UNIVERSAL PDF PIPELINE LOADED")
logger.info(f"📥 Cross-domain auto-discovery enabled across all academic fields")
logger.info(f"🌍 {len(concept_database)} concepts ready: Science, Humanities, Arts, Philosophy, Mathematics, and more!")

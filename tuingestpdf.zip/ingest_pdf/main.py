from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from ingest_pdf.pipeline import ingest_pdf_clean
import tempfile
import os
import logging

app = FastAPI()

# CORS: Allow frontend (Vite/SvelteKit) to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Logging setup
logging.basicConfig(level=logging.INFO)

@app.post("/extract")
async def extract(file: UploadFile = File(...)):
    try:
        content = await file.read()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(content)
            tmp.flush()
            tmp_path = tmp.name

        print(f"📥 Received file: {file.filename} ({len(content)} bytes)")

        result = ingest_pdf_clean(tmp_path)
        os.remove(tmp_path)

        print(f"✅ Extracted {result.get('concept_count', 0)} concepts")
        return result

    except Exception as e:
        print(f"❌ ERROR during extraction: {e}")
        return {
            "success": False,
            "error": str(e),
            "concept_count": 0,
            "concept_names": [],
            "status": "error"
        }
